<?php

header("location: public/");